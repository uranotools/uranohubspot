var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Properties/PropertiesPlugin.ts
var PropertiesPlugin_exports = {};
__export(PropertiesPlugin_exports, {
  default: () => PropertiesPlugin
});
module.exports = __toCommonJS(PropertiesPlugin_exports);
var import_GenericMcpPlugin = __toESM(require("@core/GenericMcpPlugin"));

// Plugins/mode-guard.ts
var ALLOWED = {
  full: {
    // Acceso total
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "batchCreateObjects", "batchUpdateObjects", "getSchemas"],
    Engagements: ["createEngagement", "getEngagement", "updateEngagement"],
    Properties: ["listProperties", "getProperty", "createProperty", "updateProperty"],
    Associations: ["listAssociations", "batchCreateAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink", "listWorkflows", "getWorkflow"]
  },
  readonly: {
    // Solo lectura
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "getSchemas"],
    Engagements: ["getEngagement"],
    Properties: ["listProperties", "getProperty"],
    Associations: ["listAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink", "listWorkflows", "getWorkflow"]
  },
  chat_only: {
    // Funciones que un chatbot necesita para interactuar y registrar datos
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "batchCreateObjects", "batchUpdateObjects", "getSchemas"],
    Engagements: ["createEngagement", "getEngagement", "updateEngagement"],
    Properties: ["listProperties", "getProperty"],
    Associations: ["listAssociations", "batchCreateAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink"]
  }
};
var MODE_LABELS = {
  full: "Manejo Personal Completo",
  readonly: "Solo Lectura",
  chat_only: "Solo Chatbot / Conversacional"
};
function guardMode(plugin, action, config) {
  const rawMode = config?.PLUGIN_MODE || "full";
  const mode = ["full", "readonly", "chat_only"].includes(rawMode) ? rawMode : "full";
  const allowed = ALLOWED[mode][plugin] ?? [];
  if (!allowed.includes(action)) {
    const label = MODE_LABELS[mode];
    throw new Error(
      `ATENCI\xD3N IA: La acci\xF3n '${action}' del plugin '${plugin}' no est\xE1 disponible en el modo actual del plugin ("${label}"). El usuario ha configurado este plugin para uso restringido. No intentes ejecutar esta acci\xF3n ni sugerir alternativas que la requieran. Informa al usuario que puede cambiar el modo en el MCP Manager \u2192 UranoHubSpot \u2192 Configuraci\xF3n.`
    );
  }
}

// Plugins/Properties/PropertiesPlugin.ts
var PropertiesPlugin = class extends import_GenericMcpPlugin.default {
  async executeAction(action, payload) {
    guardMode("Properties", action, this.moduleConfig);
    if (action === "listProperties") {
      return await this.callMcpTool("hubspot-list-properties", {
        objectType: payload.objectType
      });
    }
    if (action === "getProperty") {
      return await this.callMcpTool("hubspot-get-property", {
        objectType: payload.objectType,
        propertyName: payload.propertyName
      });
    }
    if (action === "createProperty") {
      const property = typeof payload.propertyJson === "string" ? JSON.parse(payload.propertyJson) : payload.property || {};
      return await this.callMcpTool("hubspot-create-property", {
        objectType: payload.objectType,
        property
      });
    }
    if (action === "updateProperty") {
      const property = typeof payload.propertyJson === "string" ? JSON.parse(payload.propertyJson) : payload.property || {};
      return await this.callMcpTool("hubspot-update-property", {
        objectType: payload.objectType,
        propertyName: payload.propertyName,
        property
      });
    }
    throw new Error(`Acci\xF3n '${action}' no soportada en PropertiesPlugin`);
  }
};
