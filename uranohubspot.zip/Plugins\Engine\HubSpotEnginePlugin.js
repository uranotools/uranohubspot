var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Engine/HubSpotEnginePlugin.ts
var HubSpotEnginePlugin_exports = {};
__export(HubSpotEnginePlugin_exports, {
  HubSpotEnginePlugin: () => HubSpotEnginePlugin
});
module.exports = __toCommonJS(HubSpotEnginePlugin_exports);
var import_EnginePluginBase = require("@core/EnginePluginBase");
var HubSpotEnginePlugin = class extends import_EnginePluginBase.EnginePluginBase {
  constructor(config) {
    super(config);
    this.config = config;
  }
  async onSessionStart(ctx) {
    console.log(`[HubSpotEnginePlugin] Sesi\xF3n iniciada: ${ctx.sessionId}`);
    const mode = this.config?.PLUGIN_MODE || "full";
    console.log(`[HubSpotEnginePlugin] Modo detectado: ${mode}`);
    if (mode === "chat_only") {
      ctx.addBadge({
        id: "hubspot-chat-active",
        label: "\u{1F916} HubSpot Chat",
        color: "success"
      });
      await ctx.store.setSession("message_count", 0);
      await ctx.store.setSession("needs_sync_check", true);
      ctx.appendCustomInstructions(
        `

[\u{1F512} M\xD3DULO HUBSPOT - PROTOCOLO DE CONVERSACI\xD3N (MODO CHAT)]
El plugin de HubSpot est\xE1 configurado en el modo: "chat_only".
Como agente, debes seguir estrictamente las siguientes reglas de negocio en esta conversaci\xF3n:
1. Al iniciar el chat, es MANDATORIO que saludes al usuario y le solicites activamente sus datos de contacto (nombre, apellido y correo electr\xF3nico) para registrarlo en el sistema. Hazlo en tu primera respuesta.
2. Tan pronto como el usuario te proporcione el primer dato significativo (ej. su correo o su nombre), debes crear de inmediato el contacto en HubSpot de fondo llamando a la herramienta 'batchCreateObjects' (objectType 'contacts'). No esperes a tener toda la informaci\xF3n.
3. Una vez creado el contacto, el sistema te inyectar\xE1 su ID de forma transparente en el contexto. A partir de ah\xED, debes usar 'batchUpdateObjects' (objectType 'contacts') con ese ID para actualizar o agregar cualquier nueva informaci\xF3n que captes durante el di\xE1logo (tel\xE9fono, empresa, notas, tratos, etc.).`
      );
    }
  }
  async onLlmInput(ctx, llmPayload) {
    const mode = this.config?.PLUGIN_MODE || "full";
    if (mode !== "chat_only") return;
    const count = await ctx.store.getSession("message_count") || 0;
    const newCount = count + 1;
    await ctx.store.setSession("message_count", newCount);
    if (newCount % 5 === 0) {
      await ctx.store.setSession("needs_sync_check", true);
    }
    const contactId = await ctx.store.getSession("hubspot_contact_id");
    const contactData = await ctx.store.getSession("hubspot_contact_data");
    const dealId = await ctx.store.getSession("hubspot_deal_id");
    const dealData = await ctx.store.getSession("hubspot_deal_data");
    const needsSync = await ctx.store.getSession("needs_sync_check");
    let dynamicCtx = "";
    if (contactId) {
      dynamicCtx += `

[HUBSPOT CONTEXTO ACTIVO (CONTACTO ID: ${contactId})]
- Est\xE1s interactuando con el contacto de HubSpot con ID: "${contactId}".
- Cualquier nuevo dato recopilado de este usuario debe guardarse/actualizarse llamando a 'batchUpdateObjects' con el objectType 'contacts' e id '${contactId}'.
- NO intentes crear un nuevo contacto. Actualiza siempre el existente.
`;
      if (contactData) {
        dynamicCtx += `- Datos actuales del contacto en HubSpot:
${JSON.stringify(contactData, null, 2)}
`;
      }
    }
    if (dealId) {
      dynamicCtx += `
[HUBSPOT TRATO ACTIVO (ID: ${dealId})]
- ID del trato comercial asociado: "${dealId}"
`;
      if (dealData) {
        dynamicCtx += `- Datos actuales del trato:
${JSON.stringify(dealData, null, 2)}
`;
      }
    }
    if (needsSync && contactId) {
      dynamicCtx += `
[INSTRUCCI\xD3N DEL SISTEMA (UN SOLO USO - SILENCIOSO)]
- Llama inmediatamente a 'batchReadObjects' para el contacto '${contactId}' (objectType 'contacts') de forma silenciosa para sincronizar cualquier cambio externo del CRM. Hazlo de fondo en este turno sin notificar al usuario.
`;
      await ctx.store.setSession("needs_sync_check", false);
    }
    if (dynamicCtx) {
      llmPayload.systemPrompt += "\n\n" + dynamicCtx;
    }
  }
  async afterToolCall(ctx, toolCall, result) {
    const mode = this.config?.PLUGIN_MODE || "full";
    if (mode !== "chat_only") return result;
    const toolName = toolCall.name.toLowerCase();
    if (toolName.includes("uranohubspot")) {
      const objectType = toolCall.arguments?.objectType;
      if (objectType === "contacts") {
        const cid = this.extractIdFromResult(result);
        if (cid) {
          const currentCid = await ctx.store.getSession("hubspot_contact_id");
          if (cid !== currentCid) {
            await ctx.store.setSession("hubspot_contact_id", cid);
            console.log(`[HubSpotEnginePlugin] Guardado nuevo contact_id en sesi\xF3n: ${cid}`);
          }
        }
        const cdata = this.extractDataFromResult(result);
        if (cdata) {
          await ctx.store.setSession("hubspot_contact_data", cdata);
          console.log(`[HubSpotEnginePlugin] Guardado contact_data actualizado en sesi\xF3n.`);
        }
      } else if (objectType === "deals") {
        const did = this.extractIdFromResult(result);
        if (did) {
          const currentDid = await ctx.store.getSession("hubspot_deal_id");
          if (did !== currentDid) {
            await ctx.store.setSession("hubspot_deal_id", did);
            console.log(`[HubSpotEnginePlugin] Guardado nuevo deal_id en sesi\xF3n: ${did}`);
          }
        }
        const ddata = this.extractDataFromResult(result);
        if (ddata) {
          await ctx.store.setSession("hubspot_deal_data", ddata);
          console.log(`[HubSpotEnginePlugin] Guardado deal_data actualizado en sesi\xF3n.`);
        }
      }
    }
    return result;
  }
  extractIdFromResult(resultContent) {
    if (!resultContent) return null;
    let text = "";
    if (typeof resultContent === "string") {
      text = resultContent;
    } else if (typeof resultContent === "object") {
      if (Array.isArray(resultContent.content)) {
        text = resultContent.content.map((c) => c.text || "").join(" ");
      } else if (resultContent.content && typeof resultContent.content === "string") {
        text = resultContent.content;
      } else {
        text = JSON.stringify(resultContent);
      }
    }
    try {
      const parsed = JSON.parse(text);
      if (parsed.results && Array.isArray(parsed.results) && parsed.results.length > 0) {
        return parsed.results[0].id || null;
      }
      if (parsed.id) {
        return parsed.id;
      }
    } catch {
    }
    const idRegex = /"id"\s*:\s*"(\d+)"/i;
    const match = text.match(idRegex);
    if (match && match[1]) {
      return match[1];
    }
    return null;
  }
  extractDataFromResult(resultContent) {
    if (!resultContent) return null;
    let text = "";
    if (typeof resultContent === "string") {
      text = resultContent;
    } else if (typeof resultContent === "object") {
      if (Array.isArray(resultContent.content)) {
        text = resultContent.content.map((c) => c.text || "").join(" ");
      } else if (resultContent.content && typeof resultContent.content === "string") {
        text = resultContent.content;
      } else {
        text = JSON.stringify(resultContent);
      }
    }
    try {
      const parsed = JSON.parse(text);
      if (parsed.results && Array.isArray(parsed.results) && parsed.results.length > 0) {
        return parsed.results[0].properties || parsed.results[0];
      }
      if (parsed.properties) {
        return parsed.properties;
      }
      return parsed;
    } catch {
      return null;
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HubSpotEnginePlugin
});
