var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/CRM/CRMPlugin.ts
var CRMPlugin_exports = {};
__export(CRMPlugin_exports, {
  default: () => CRMPlugin
});
module.exports = __toCommonJS(CRMPlugin_exports);
var import_GenericMcpPlugin = __toESM(require("@core/GenericMcpPlugin"));

// Plugins/mode-guard.ts
var ALLOWED = {
  full: {
    // Acceso total
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "batchCreateObjects", "batchUpdateObjects", "getSchemas"],
    Engagements: ["createEngagement", "getEngagement", "updateEngagement"],
    Properties: ["listProperties", "getProperty", "createProperty", "updateProperty"],
    Associations: ["listAssociations", "batchCreateAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink", "listWorkflows", "getWorkflow"]
  },
  readonly: {
    // Solo lectura
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "getSchemas"],
    Engagements: ["getEngagement"],
    Properties: ["listProperties", "getProperty"],
    Associations: ["listAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink", "listWorkflows", "getWorkflow"]
  },
  chat_only: {
    // Funciones que un chatbot necesita para interactuar y registrar datos
    CRM: ["listObjects", "searchObjects", "batchReadObjects", "batchCreateObjects", "batchUpdateObjects", "getSchemas"],
    Engagements: ["createEngagement", "getEngagement", "updateEngagement"],
    Properties: ["listProperties", "getProperty"],
    Associations: ["listAssociations", "batchCreateAssociations", "getAssociationDefinitions"],
    System: ["getUserDetails", "getLink"]
  }
};
var MODE_LABELS = {
  full: "Manejo Personal Completo",
  readonly: "Solo Lectura",
  chat_only: "Solo Chatbot / Conversacional"
};
function guardMode(plugin, action, config) {
  const rawMode = config?.PLUGIN_MODE || "full";
  const mode = ["full", "readonly", "chat_only"].includes(rawMode) ? rawMode : "full";
  const allowed = ALLOWED[mode][plugin] ?? [];
  if (!allowed.includes(action)) {
    const label = MODE_LABELS[mode];
    throw new Error(
      `ATENCI\xD3N IA: La acci\xF3n '${action}' del plugin '${plugin}' no est\xE1 disponible en el modo actual del plugin ("${label}"). El usuario ha configurado este plugin para uso restringido. No intentes ejecutar esta acci\xF3n ni sugerir alternativas que la requieran. Informa al usuario que puede cambiar el modo en el MCP Manager \u2192 UranoHubSpot \u2192 Configuraci\xF3n.`
    );
  }
}

// Plugins/CRM/CRMPlugin.ts
var CRMPlugin = class extends import_GenericMcpPlugin.default {
  async executeAction(action, payload) {
    guardMode("CRM", action, this.moduleConfig);
    if (action === "listObjects") {
      return await this.callMcpTool("hubspot-list-objects", {
        objectType: payload.objectType,
        limit: payload.limit ? Number(payload.limit) : void 0,
        after: payload.after,
        properties: payload.properties,
        associations: payload.associations
      });
    }
    if (action === "searchObjects") {
      return await this.callMcpTool("hubspot-search-objects", {
        objectType: payload.objectType,
        query: payload.query,
        limit: payload.limit ? Number(payload.limit) : void 0,
        after: payload.after
      });
    }
    if (action === "batchReadObjects") {
      const ids = (payload.ids || "").split(",").map((id) => id.trim()).filter(Boolean);
      const inputs = ids.map((id) => ({ id }));
      return await this.callMcpTool("hubspot-batch-read-objects", {
        objectType: payload.objectType,
        inputs
      });
    }
    if (action === "batchCreateObjects") {
      console.log("[CRMPlugin] batchCreateObjects raw payload:", JSON.stringify(payload, null, 2));
      let inputs;
      try {
        inputs = typeof payload.inputsJson === "string" ? JSON.parse(payload.inputsJson) : payload.inputsJson || [];
      } catch (err) {
        throw new Error(`JSON.parse failed for inputsJson: "${payload.inputsJson}". Error: ${err.message}`);
      }
      if ((!inputs || inputs.length === 0) && payload.inputs) {
        inputs = payload.inputs;
      }
      console.log("[CRMPlugin] final inputs for callMcpTool:", JSON.stringify(inputs, null, 2));
      return await this.callMcpTool("hubspot-batch-create-objects", {
        objectType: payload.objectType,
        inputs
      });
    }
    if (action === "batchUpdateObjects") {
      console.log("[CRMPlugin] batchUpdateObjects raw payload:", JSON.stringify(payload, null, 2));
      let inputs;
      try {
        inputs = typeof payload.inputsJson === "string" ? JSON.parse(payload.inputsJson) : payload.inputsJson || [];
      } catch (err) {
        throw new Error(`JSON.parse failed for inputsJson: "${payload.inputsJson}". Error: ${err.message}`);
      }
      if ((!inputs || inputs.length === 0) && payload.inputs) {
        inputs = payload.inputs;
      }
      console.log("[CRMPlugin] final inputs for callMcpTool:", JSON.stringify(inputs, null, 2));
      return await this.callMcpTool("hubspot-batch-update-objects", {
        objectType: payload.objectType,
        inputs
      });
    }
    if (action === "getSchemas") {
      return await this.callMcpTool("hubspot-get-schemas", {});
    }
    throw new Error(`Acci\xF3n '${action}' no soportada en CRMPlugin`);
  }
};
